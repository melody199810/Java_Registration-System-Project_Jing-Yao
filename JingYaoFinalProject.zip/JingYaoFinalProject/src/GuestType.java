public enum GuestType {
    GUEST,
	USER, 
	STAFF,
    HOST;
}
